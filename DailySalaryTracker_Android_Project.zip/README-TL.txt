DAILY SALARY TRACKER — GABAY SA PAGGAWA NG APK

Kasama sa project na ito ang Daily Hours & Salary Tracker na naka-wrap bilang Android app.
Default rate: P57/hour.
Cutoff 10–24: payday tuwing ika-4.
Cutoff 25–9: payday tuwing ika-20.
Ang daily entries ay naka-save sa local storage ng app.

PAANO KUNIN ANG APK GAMIT ANG GITHUB (PUWEDE SA PHONE)

1. Pumunta sa https://github.com at gumawa ng account o mag-sign in.
2. Gumawa ng bagong repository. Pangalanan itong DailySalaryTracker.
3. Piliin ang Upload files.
4. I-extract muna ang ZIP na ito. I-upload ang LAHAT ng laman ng folder sa repository root.
   Siguraduhing kasama ang folder na .github (maaaring kailanganin ang GitHub website sa browser at Desktop site).
5. I-commit ang files sa branch na main.
6. Buksan ang Actions tab ng repository.
7. Piliin ang workflow na "Build Daily Salary Tracker APK", pagkatapos Run workflow kung hindi ito kusang tumakbo.
8. Hintaying maging green ang build.
9. Buksan ang successful workflow run, hanapin ang Artifacts, at i-download ang
   Daily-Salary-Tracker-APK.
10. I-extract ang na-download na artifact ZIP. Makikita roon ang app-debug.apk.
11. Buksan ang APK sa Android phone. Kung hingin, payagan ang installation mula sa browser/files app.
    I-install lamang ang APK na ikaw mismo ang nag-build mula sa sarili mong repository.

PAALALA
- Kailangan ng internet para sa GitHub build.
- Ito ay debug APK para sa personal testing, hindi pa Play Store release.
- Hindi kailangan ng app ng internet habang ginagamit; entries ay naka-save sa device.
- Huwag i-clear ang app data kung ayaw mong mawala ang saved hours.
- Ang APK ay hindi pa na-build dito; ang GitHub Actions ang gagawa nito kapag nasunod ang steps.
